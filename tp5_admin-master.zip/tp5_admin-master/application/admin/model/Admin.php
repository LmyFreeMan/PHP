<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/11
 * Time: 10:28
 */

namespace app\admin\model;
use think\Model;

class Admin extends Model
{

}