<?php
namespace app\admin\controller;

use think\Session;

class Users extends Common
{

}
