<?php
namespace app\admin\controller;

use think\Db;
use think\Session;

class Admin extends Common
{


}
