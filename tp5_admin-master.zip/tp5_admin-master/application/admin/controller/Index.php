<?php
namespace app\admin\controller;

use think\Session;

class Index extends Common
{
    public function index($path='index')
    {

        return $this->fetch('index');
    }


}
