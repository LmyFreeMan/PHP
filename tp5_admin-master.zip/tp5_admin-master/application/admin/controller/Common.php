<?php
namespace app\admin\controller;
use think\Controller;
use think\Session;
use think\Db;

class Common extends Controller
{
    protected $controller;
    protected $lower_controller;
    protected $module;
    protected $action;

    public function __construct()
    {
        parent::__construct();
        $this->check_login();
        $this->controller = request()->controller();
        $this->lower_controller = strtolower($this->controller);
        $this->module = request()->module();
        $this->action = request()->action();

        $this->nav();
    }

    public function check_login(){
        if(!Session::has('admin')){
            header("Location: http://www.qndr.com/admin/Login/login.html");
        }
    }

    public function nav(){//加载导航栏
        $once_nav_data = Db::table('qndr_nav')->where(['pid'=>0,'status'=>1])->select();//所有以级导航
        foreach($once_nav_data as $key => $value){
            $child = Db::table('qndr_nav')->where(['pid'=>$value['id'],'status'=>1])->select();
            $once_nav_data[$key]['child'] = $child;
        }
        $this->assign('leftNav',$once_nav_data);
    }

    public function index($path = 'index')
    {

        $data = db($this->lower_controller)->select();
        $this->assign('data',$data);
        return $this->fetch($path);
    }

    public function add(){
        if(request()->isPost()){
            $get_info = request()->post();
            $res = db($this->lower_controller)->insert($get_info);
            if($res){
                $this->success("添加成功",url($this->module.'/'.$this->controller.'/index'));
            }else{
                $this->error('添加失败');
            }
        }
        $add_data = db($this->lower_controller)->select();
        $this->assign('add_data',$add_data);
        return $this->fetch();
    }


    public function del(){
        $id = input('post.id');
        $res = db($this->lower_controller)->delete($id);
        if($res){
            $ret = [
                'success' => 1,
                'hint' => '删除成功',
            ];
        }else{
            $ret = [
                'success' => 2,
                'hint' => '删除失败',
            ];
        }
        echo json_encode($ret);

    }

    public function update(){
        $id = input('param.id');//获取url美化过后的请求值   需要用input('param.')类型;
        if(request()->isPost()){
            $post_info = input('post.');
            $res = db($this->lower_controller)->where(['id'=>$id])->update($post_info);
            if($res !== false){
                $this->success('修改成功',url($this->module.'/'.$this->controller.'/index'));
            }else{
                $this->error('修改失败');
            }
        }

        $update_data = db($this->lower_controller)->where(['id'=>$id])->find();
        $this->assign('update_data',$update_data);
        return $this->fetch();
    }



}
