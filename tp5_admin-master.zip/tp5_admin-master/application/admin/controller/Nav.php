<?php
namespace app\admin\controller;
use think\Request;
use think\Db;
use think\Session;

class Nav extends Common
{
    public function index($path='index')
    {

        $data = db('nav')->select();
        $nav_info = $this->_reSort($data);
        $this->assign('nav_info',$nav_info);
        return $this->fetch('index');
    }

    public function add(){
        if(Request::instance()->isPost()){
            $get_info = Request::instance()->post();
            $res = Db::table('qndr_nav')->insert($get_info);
            if($res){
                $this->success("添加成功",url('admin/Nav/index'));
            }else{
                $this->error('添加失败');
            }
        }
        $nav_info = Db::table('qndr_nav')->where(['pid'=>0])->select();
        $this->assign('nav_info',$nav_info);
        return $this->fetch('add');
    }


    public function update(){//这个$id是框架获取get或post参数
        $id = input('param.id');
        if(request()->isPost()){
            $post_info = input('post.');
            $res = db('nav')->where(['id'=>$id])->update($post_info);
            if($res !== false){
                $this->success('修改成功',url('admin/Nav/index'));
            }else{
                $this->error('修改失败');
            }
        }

        $parent_nav = db('nav')->where(['pid'=>0])->select();
        $nav_info = db('nav')->where(['id'=>$id])->find();
        $this->assign('nav_info',$nav_info);
        $this->assign('parent_nav',$parent_nav);
        return $this->fetch();
    }

    public function del(){
        $id = input('post.id');
        $res = db('nav')->delete($id);
        if($res){
            $ret = [
                'success' => 1,
                'hint' => '删除成功',
            ];
        }else{
            $ret = [
                'success' => 2,
                'hint' => '删除失败',
            ];
        }
        echo json_encode($ret);

    }


    protected function _reSort($data, $parent_id = 0, $level = 0, $isClear = TRUE) {//递归
        static $ret = array();
        if ($isClear)
            $ret = array();
        foreach ($data as $k => $v) {
            if ($v['pid'] == $parent_id) {
                $v['level'] = $level;
                $ret[] = $v;
                $this->_reSort($data, $v['id'], $level + 1, FALSE);
            }
        }
        return $ret;
    }

}
