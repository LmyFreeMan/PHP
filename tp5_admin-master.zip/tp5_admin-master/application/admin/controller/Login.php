<?php
namespace app\admin\controller;

use think\Controller;
use think\Request;
use think\Db;
use app\admin\model\Admin;
use think\Session;

class Login extends Controller
{
    public function login(){
        if(Request::instance()->isPost()){//判断是post请求
            $request = Request::instance();
            $data = $request->param();
            if($data['user_name'] == '' || $data['user_name'] == null){
                $hints = [
                    'success' => 2,
                    'hint' => '请输入用户名'
                ];
                echo json_encode($hints);
                exit;
            }else if($data['password'] == '' || $data['password'] == null){
                $hints = [
                    'success' => 3,
                    'hint' => '请输入密码'
                ];
                echo json_encode($hints);
                exit;
            }
            $where['user_name'] = $data['user_name'];
            $res = Db::table("qndr_admin")->where($where)->find();

            if($res){
                if($res['password'] == md5($data['password'])){//登录成功跳转到首页
//                    header("Location: ".APP_URL."admin/Index/index.html");
                    Session::set('admin',$res);//设置用户session
                    $hints = [
                        'success' => 1,
                        'hint' => '登录成功'
                    ];
                    echo json_encode($hints);
                    exit;
                }else{
                    $hints = [
                        'success' => 5,
                        'hint' => '密码错误'
                    ];
                    echo json_encode($hints);
                    exit;
                }
            }else{
                $hints = [
                    'success' => 4,
                    'hint' => '请输入正确的用户名'
                ];
                echo json_encode($hints);
                exit;
            }

        }
        return $this->fetch('login');
    }

    public function loginout(){

        if(Session::has('admin')){
            Session::delete('admin');
        }
        header("Location: ".url('admin/Login/login'));
    }


}
