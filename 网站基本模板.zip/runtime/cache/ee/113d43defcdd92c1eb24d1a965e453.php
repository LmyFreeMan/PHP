<?php
//000000000002
 exit();?>
a:5:{s:2:"id";i:1;s:3:"aid";i:1;s:5:"value";d:0.5;s:3:"sid";s:0:"";s:4:"flag";i:0;}