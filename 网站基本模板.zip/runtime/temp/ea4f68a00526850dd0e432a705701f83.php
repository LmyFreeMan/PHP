<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:57:"/var/www/html/dier/application/admin/view/index/edit.html";i:1523429119;s:58:"/var/www/html/dier/application/admin/view/common/mask.html";i:1518170940;s:60:"/var/www/html/dier/application/admin/view/common/header.html";i:1518497100;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<!-- 引入头部 -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>第二课堂后台管理</title>
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="/dier/static/css/layui.css">
<script src="/dier/static/layui.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<link href="/dier/static/ueditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="/dier/static/ueditor/third-party/jquery.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/dier/static/ueditor/umeditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/dier/static/ueditor/umeditor.min.js"></script>
<script type="text/javascript" src="/dier/static/ueditor/lang/zh-cn/zh-cn.js"></script>
</head>
<body>
	<div class="layui-layout layui-layout-admin">
	
	
    	<!-- 内容主体区域 -->
	  	<div class="layui-tab layui-tab-brief" lay-filter="demoTitle">
			<div class="layui-tab-content site-demo site-demo-body">
			  <div class="layui-tab-item layui-show">
				<div class="layui-main">
				  <div id="LAY_preview">
				  
				<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
					<legend>编辑</legend>
				</fieldset>
					<form class="layui-form" action="/dier/admin/Service/edit" method="post" lay-filter="sub">
						<input type="hidden" name="tablename" value="<?php echo $flag; ?>">
					  <?php if(is_array($cols) || $cols instanceof \think\Collection || $cols instanceof \think\Paginator): $i = 0; $__LIST__ = $cols;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					  
					  
					  <div class="layui-form-item">
						<label class="layui-form-label"><?php echo $vo['comment']; ?></label>
						<div class="layui-input-block">
							<?php if($vo['field'] == 'id'): ?>
							<input type="text" name="<?php echo $vo['field']; ?>" value="<?php echo $vo['value']; ?>" autocomplete="off" class="layui-input" readonly>
							<?php else: ?>
							<input type="text" name="<?php echo $vo['field']; ?>" value="<?php echo $vo['value']; ?>" autocomplete="off" class="layui-input">
							<?php endif; ?>
						  
						</div>
					  </div>
					 
					  <?php endforeach; endif; else: echo "" ;endif; ?>
					<div class="layui-form-item">
						<div class="layui-input-block">
					<input type="submit" value ="提交" class="layui-btn" lay-submit="" lay-filter="demo1" >
					    </div>
					</div>
					</form>
					
			</div>
          </div>
        </div>
      </div>
	  <script>
		layui.use('form', function(){
		  var form = layui.form;
		  
			  form.on('submit(sub)', function(data){
				 console.log(data.elem) //被执行事件的元素DOM对象，一般为button对象
				 console.log(data.form) //被执行提交的form对象，一般在存在form标签时才会返回
				 console.log(data.field) //当前容器的全部表单字段，名值对形式：{name: value}
				 
			  
			});
		});
		
	  </script>
	
	</div>
</body>
</html>
