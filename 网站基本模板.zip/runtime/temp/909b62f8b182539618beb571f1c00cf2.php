<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:59:"/var/www/html/dier/application/admin/view/index/leadin.html";i:1523432681;s:60:"/var/www/html/dier/application/admin/view/common/common.html";i:1519012292;s:60:"/var/www/html/dier/application/admin/view/common/header.html";i:1518497100;s:58:"/var/www/html/dier/application/admin/view/common/left.html";i:1524832603;s:64:"/var/www/html/dier/application/admin/view/common/nav-header.html";i:1519035584;s:60:"/var/www/html/dier/application/admin/view/common/footer.html";i:1518170940;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<!-- 引入头部 -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>第二课堂后台管理</title>
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="/dier/static/css/layui.css">
<script src="/dier/static/layui.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<link href="/dier/static/ueditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="/dier/static/ueditor/third-party/jquery.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/dier/static/ueditor/umeditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/dier/static/ueditor/umeditor.min.js"></script>
<script type="text/javascript" src="/dier/static/ueditor/lang/zh-cn/zh-cn.js"></script>
</head>
<body>
	<div class="layui-layout layui-layout-admin">
    <!-- 引入左侧栏 -->
    <div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav layui-nav-tree" lay-filter="test">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$parent): $mod = ($i % 2 );++$i;?>
		<li class="layui-nav-item">
		  <?php if($parent['pid'] == '0'): ?>
          <a  href="javascript:;"><?php echo $parent['name']; ?></a>
		  <dl class="layui-nav-child">
		  <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$child): $mod = ($i % 2 );++$i;if($child['pid'] != '0'): if($parent['id'] == $child['pid']): if(empty($child['right']) || (($child['right'] instanceof \think\Collection || $child['right'] instanceof \think\Paginator ) && $child['right']->isEmpty())): ?>
			<dd><a class="mantype" href="/dier/admin/Index/manpage?id=<?php echo $child['id']; ?>"><?php echo $child['name']; ?></a></dd>
			<?php endif; if(!(empty($child['right']) || (($child['right'] instanceof \think\Collection || $child['right'] instanceof \think\Paginator ) && $child['right']->isEmpty()))): ?>
			<dd><a class="mantype" href="/dier/<?php echo $child['right']; ?>?id=<?php echo $child['id']; ?>"><?php echo $child['name']; ?></a></dd>
			<?php endif; endif; endif; endforeach; endif; else: echo "" ;endif; ?>
			 </dl>
			<?php endif; ?>
        </li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
	  <script>
	var a=location.href.split('/');
		var len=a.length;
		
	   var a1 = $('.layui-nav-item a').each(
			function(){
			var href=$(this).attr('href');
				if(href==a[len-1])
				{
					$(this).parent().parent().parent().addClass('layui-nav-itemed');
					$(this).parent().addClass('layui-nav-itemed');
				}
			}
	   )
</script>
    </div>
  </div>


	
	
	<!-- 引入左侧栏 -->
		  <div class="layui-header">
    <div class="layui-logo">第二课堂 后台管理</div>
    <!-- 头部区域（可配合layui已有的水平导航） -->
  
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item"><a href="">退出</a></li>
    </ul>
  </div>
		<div class="layui-body">
    	<!-- 内容主体区域 -->
	  	<div class="layui-tab layui-tab-brief" lay-filter="demoTitle">
			<div class="layui-tab-content site-demo site-demo-body">
			  <div class="layui-tab-item layui-show">
				<div class="layui-main">
				  <div id="LAY_preview">
				  
				<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
					<legend>导入学生活动信息</legend>
				</fieldset>
					<form class="layui-form" action="/dier/admin/Service/add" method="post" lay-filter="sub">
						<input type="hidden" name="flag" value="">
					 
					  
					<div class="layui-form-item">
					
						<div class="layui-input-block">
					 <button type="button" class="layui-btn layui-btn-primary" id="test4"><i class="layui-icon"></i>只允许压缩文件</button>
					    </div>
					</div>
					</form>
					
			</div>
          </div>
        </div>
      </div>
	  </div>
	  <script>
		var um = UM.getEditor('myEditor');
		layui.use(['form','laydate','upload'], function(){
	  var form = layui.form
	  ,laydate = layui.laydate
	  ,$ = layui.jquery
	  ,upload = layui.upload;
	    //普通上传
	  upload.render({
		url: '<?php echo url("/dier/upload"); ?>'
		,elem:'#image'
		,ext: 'jpg|png|gif'
		,area: ['500', '500px']
		,before: function(input){
		loading = layer.load(2, {
		shade: [0.2,'#000']
		});
		}
		,done: function(res){
		layer.close(loading);
		$('input[name=img]').val(res.path);
		img.src = "/dier/public/Uploads/"+res.path;
		layer.msg(res.msg, {icon: 1, time: 1000});
		}
	  }); 
	   //日期
	  laydate.render({
		elem: '#date'
		,type: 'datetime'
	  });
	  laydate.render({
		elem: '#date1'
		,type: 'datetime'
	  });
	  laydate.render({
		elem: '#date2'
		,type: 'datetime'
	  });
	  //监听提交
	  form.on('submit(formDemo)', function(data){
		layer.msg(JSON.stringify(data.field));
		
	  });
	});
		
	  </script>
	
	<div class="layui-footer">
<!-- 底部固定区域 -->
© huihua.hebtu.edu.cn 第二课堂 - 后台管理
</div>
	</div>
	<script>
		//JavaScript代码区域
		layui.use('element', function(){
		  var element = layui.element;
		  
		  element.on('tab(filter)', function(data){
		  console.log(this); //当前Tab标题所在的原始DOM元素
		  console.log(data.index); //得到当前Tab的所在下标
		  console.log(data.elem); //得到当前的Tab大容器
		});
		});
		
	</script>
</body>
</html>
