<?php
namespace app\admin\model;

use think\Model;
use think\Db;
class ActivelogModel extends Model
{
	protected $table = 'xy_activelog';
    protected $pk = 'id';
	protected $resultSetType = 'collection';
	public function getflagAttr($value)
    {
        $flag = [0=>'待审核',1=>'已审核'];
		
        return $flag[$value];
    }
	public function getaidAttr($value)
    {
        $actinfo = Db::name('activeinfo')->select();
		foreach($actinfo as $key=>$val)
		{
			$aid[$val['id']]=$val['title'];
		}
        return $aid[$value];
    }
	
	protected function initialize()
    {
        //需要调用`Model`的`initialize`方法
        parent::initialize();
        //TODO:自定义的初始化
    }
}