<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Request;
use tree\Tree;
use PHPExcel;
class Index extends Controller
{
	public function _initialize()
    {
		#网站基本信息加载
		$settinginfo=Db::name("settinginfo")->find();
		$this->assign("settinginfo",$settinginfo);
		#后台菜单加载
		$menuinfo=Db::name("sys_menuinfo")->order('list_order','asc')->select();
		$this->assign("menu",$menuinfo);
		
    }
	public function datagridcols($tablename)
	{
		$info=Db::name($tablename)->gettableinfo();
		$str="";
		for($i=0;$i<count($info['fields']);$i++)
		{
			$str=$str.",{field:'".$info['fields'][$i]."', title: '".$info['comment'][$i]."'}";
			
		}
		$this->assign("colsinfo",$str);
		$this->assign("tablename",$tablename);
	}
    /*
	登录页面
	*/
    public function index()
    {
		return $this->fetch('login');
    }
	public function menu(){
		$info = array(
		'操作系统'=>PHP_OS,
		'运行环境'=>$_SERVER["SERVER_SOFTWARE"],
		'PHP运行方式'=>php_sapi_name(),
		'ThinkPHP版本'=>THINK_VERSION.' [ <a href="http://thinkphp.cn" target="_blank">查看最新版本</a> ]',
		'上传附件限制'=>ini_get('upload_max_filesize'),
		'执行时间限制'=>ini_get('max_execution_time').'秒',
		'服务器时间'=>date("Y年n月j日 H:i:s"),
		'北京时间'=>gmdate("Y年n月j日 H:i:s",time()+8*3600),
		'服务器域名/IP'=>$_SERVER['SERVER_NAME'].' [ '.gethostbyname($_SERVER['SERVER_NAME']).' ]',
		'剩余空间'=>round((disk_free_space(".")/(1024*1024)),2).'M',
		);
		$this->assign('info',$info);
		return $this->fetch('index');
	}
	/*构造字段及字段注释数组*/
	public function gettable($id)
	{
		$data=Db::name('sys_menuinfo')->where('id',$id)->find();
		$info=Db::query('show full fields from xy_'.$data['tablename']);
		
		$this->assign("colsinfo",$info);
		$this->assign("id",$id);
	}
	/*
	管理页面
	*/
	public function manpage($id)
	{
		
		$menuinfo=Db::name("sys_menuinfo")->where("id",$id)->find();
		action('service/datagridfield',$menuinfo['tablename']);
		$this->assign('tablename',$menuinfo['tablename']);
		$this->assign('add',$menuinfo['add']);
		$this->assign('qxm',$menuinfo['qxm']);
		
		return $this->fetch('manpage');
	}
	public function man()
	{
		return $this->fetch('man');
	}
	public function ccc()
	{
		return $this->fetch();
	}
	/*
	编辑修改
	*/
	public function edit(){
        $id = Request::instance()->get('id');
        $flag = Request::instance()->get('flag');
        $data1 = Db::name($flag)->where('id',$id)->find();
		$info=Db::name($flag)->gettableinfo();
		
		for($i=0;$i<count($info['fields']);$i++)
		{
			$cols[$i]['field']=$info['fields'][$i];
			$cols[$i]['comment']=$info['comment'][$i];
			if($info['fields'][$i]=='password')
				$cols[$i]['value']=base64_decode($data1[$info['fields'][$i]]);
			else
				$cols[$i]['value']=$data1[$info['fields'][$i]];
			
		}
        $this->assign('flag',$flag);
        $this->assign('cols',$cols);
        return $this->fetch();
    }
    /*
	添加操作
    */
    public function add(){
    	$id = Request::instance()->get('id');
		$this->gettable($id);
    	
    	// print_r($data);	
    	// print_r($fields);
    	#$this->assign('flag',$flag);
    	#$this->assign('fields',$fields);
    	return $this->fetch();
    }
	public function te()
	{
		return $this->fetch('menulist');
	}
	public function test()
	{
		//模拟数据库  
			$data=array(  
				array('id'=>1,'pid'=>0,'name'=>'一级栏目一'),  
				array('id'=>2,'pid'=>0,'name'=>'一级栏目二'),  
				array('id'=>3,'pid'=>1,'name'=>'二级栏目一'),  
				array('id'=>4,'pid'=>3,'name'=>'三级栏目一'),  
				array('id'=>5,'pid'=>4,'name'=>'四级栏目一'),  
			);  
			  
			//转换数据  
			$tree_data=array();  
			foreach ($data as $key=>$value){  
				$tree_data[$value['id']]=array(  
					'id'=>$value['id'],  
					'parentid'=>$value['pid'],  
					'name'=>$value['name']  
				);  
			}  
			  
			/** 
			 * 输出树形结构 
			 */  
			$str="<tr>  
				<td><input type='checkbox' name='list[\$id]' value='\$id'></td>  
				<td>\$id</td>  
				<td>\$spacer\$name</td>  
				<td><a href='add.php?id=\$id'>添加</a></td>  
				<td><a href='del.php?id=\$id'>删除</a></td>  
				<td><a href='update.php?id='\$id'>修改</a></td>  
				</tr>";  
			  
			$tree=new Tree();  
			$tree->init($tree_data);  
			echo "<table>";  
			echo $tree->get_tree(0, $str);  
			echo "</table>";  
			  

			  
			/** 
			 * 输出下拉列表 
			 */  
			  
			$str="<option value=\$id \$selected>\$spacer\$name</option>";  
			$tree=new Tree();  
			$tree->init($tree_data);  
			echo "<select>";  
			echo $tree->get_tree(0,$str,2);  
			echo "</select>"; 
		
	}
	public function Addact()
	{
		return $this->fetch();
	}
	public function page($page)
	{
		return $this->fetch($page);
	}
	public function leadin()
	{
		return $this->fetch();
		
		
		
	}
}
