<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
use think\Request;
use think\Url;

class Service  extends Controller {

    /*
    登录
    */
    public function login(){
         /**检验用户名和密码是否正确**/
        $username = trim(Request::instance()->post('username'));      //接受用户名，并且用trim函数去除首尾空格
        $password = trim(Request::instance()->post('password'));       //接受密码，并且用trim函数去除首尾空格
		
        $return = $this->checkPassword($username,$password);
        if(!$return){
            $this->error("账号或密码错误",url('admin/index/index'));
        }else{
            session('tid',$return["id"]);             //将tid存入session
            session('tusername',$return["username"]); //将tusername存入session
			
            $this->success("登录成功",url('admin/index/menu'));
        }
    }
    /*
    验证密码
    */
    public function checkPassword($username,$password){
        $admin = Db::name('teacherinfo')->where('username',$username)->find();
        if(base64_decode($admin['password']) == $password){
			$request = Request::instance();
			$clientip = $request->ip();
			Db::name('teacherinfo')->where('username',$username)->update(['clientip'=>$clientip,'lastlogin'=>date("Y-m-d H:i:s")]);
            return $admin;
        }else{
            return false;
        } 
    }
	/*构造字段及字段注释数组*/
	public function datagridcols($tablename)
	{
		$info=Db::name($tablename)->gettableinfo();
		$str="";
		for($i=0;$i<count($info['fields']);$i++)
		{
			$str=$str.",{field:'".$info['fields'][$i]."', title: '".$info['comment'][$i]."'}";
			
		}
		$this->assign("colsinfo",$str);
		$this->assign("tablename",$tablename);
	}
    /*
	查询操作
    */
   /* public function select(){
    	$flag = Request::instance()->get('flag');
    	$page=Request::instance()->get('page');
		$limit=Request::instance()->get('limit');
		$aid=Request::instance()->get('aid');
		if(isset($aid))
		{
			$where['aid']=Request::instance()->get('aid');
			$where['flag']='0';
		}
		else
		{
			$where['flag']='0';
		}
		$now=($page-1)*10;
		if($flag=='activelog')
		{
		$act = model('ActivelogModel');
		$data=$act->where($where)->limit($now,$limit)->select();
		$count=DB::name($flag)->count();
		}
		else{
		$data=Db::name($flag)->limit($now,$limit)->select();
		$count=DB::name($flag)->count();
		}
		return json(0,"success",$count,$data);
    }*/
	public function select()
    {
		$where='';
		if(null!=Request::instance()->get('field'))
		{
			$where[Request::instance()->get('field')]=Request::instance()->get('value');
		}
        $flag = Request::instance()->get('flag');
        $page = Request::instance()->get('page');
        $limit = Request::instance()->get('limit');
        $now = ($page - 1) * 10;
		if($flag=='activelog')
		{
		$act = model('ActivelogModel');
		$data=$act->where($where)->limit($now,$limit)->select();
		$count=DB::name($flag)->count();
		}
		else{
		$data=Db::name($flag)->limit($now,$limit)->select();
		$count=DB::name($flag)->count();
		}
        return json(0, "success", $count, $data);
    }
    /*
	删除操作
    */
    public function del(){
    	$id = Request::instance()->get('id');
    	$flag = Request::instance()->get('flag');
    	Db::name($flag)->where('id',$id)->delete();
    }
    /*
	修改操作
    */
   public function edit(){
    	$flag = Request::instance()->post('tablename');
		
        $fields = Db::name($flag)->getTableInfo();
        foreach ($fields['fields'] as $key => $value) {
            $data[$value] = Request::instance()->post($value);
        }
        Db::name($flag)->update($data);
    }
    /*
    添加操作
    */
    public function add(){
        $flag = Request::instance()->post('flag');
        $fields = Db::getTableInfo($flag,'fields');
        foreach ($fields as $key => $value) {
            $data[$value] = Request::instance()->post($value);
        }
        Db::name($flag)->insert($data);
    }
	public function addact()
	{
		$fields=Db::name("activeinfo")->gettableinfo();
		foreach($fields['fields'] as $key=>$val)
		{
			if($val<>'id')
			$data[$val]=Request::instance()->param($val);
			
		}
		Db::name('activeinfo')->insert($data);
		
	}
	public function checkstu()
	{
		
		$request=Request::instance()->param('response');
		$list=json_decode($request);
		foreach($list as $key=>$val)
		{
			$value=object_to_array($val);
			Db::name('studentinfo')->where('id',$value['sid'])->setInc('grade', $value['value']);
			Db::name('activelog')->where('id',$value['id'])->setInc('flag',1);
		}
		return 'success';
	}
	public function datagridfield($table)
    {
        $fields = Db::query('show full columns from xy_' . $table . ';');
        $string = "";
        foreach ($fields as $key => $val) {
            $string = $string . ",{field:'" . $val['Field'] . "', title: '" . $val['Comment'] . "'}";
        }
		
		$this->assign('tableframe',$fields);
        $this->assign('datagridfield', $string);
    }
	
	/*public function leadonexcel()
	{
		vendor("PHPExcel.PHPExcel");
		$objPHPExcel = new \PHPExcel();  
  
        //获取表单上传文件  
        $file = request()->file('excel');  
        $info = $file->validate(['ext'=>'xlsx,xls,csv'])->move(ROOT_PATH . 'public' . DS . 'excel');  
        if($info){  
            $exclePath = $info->getSaveName();  //获取文件名  
            $file_name = ROOT_PATH . 'public' . DS . 'excel' . DS . $exclePath;   //上传文件的地址  
            $objReader =\PHPExcel_IOFactory::createReader('Excel2007');  
            $obj_PHPExcel =$objReader->load($file_name, $encode = 'utf-8');  //加载文件内容,编码utf-8  
            echo "<pre>";  
            $excel_array=$obj_PHPExcel->getsheet(0)->toArray();   //转换为数组格式  
            array_shift($excel_array);  //删除第一个数组(标题);  
            $data = [];  
            $i=0;  
            foreach($excel_array as $k=>$v) {  
                $data[$k]['title'] = $v[0];  
                $i++;  
            }  
          
        }else{  
            // 上传失败获取错误信息  
            echo $file->getError();  
        }  
		
		
	}
	*/
	public function logtoexcel($response)
	{
		$d=object_to_array(json_decode($response));
		$aid=Db::name('activeinfo')->where('title',$d[0]['aid'])->find();
		$act = model('ActivelogModel');
		$data=$act->where('aid',$aid['id'])->select();
		Vendor('PHPExcel.PHPExcel');//调用类库,路径是基于vendor文件夹的
        Vendor('PHPExcel.PHPExcel.Worksheet.Drawing');
        Vendor('PHPExcel.PHPExcel.Writer.Excel2007');
		//创建对象  
		$objExcel = new \PHPExcel();
        //set document Property
        $objWriter = \PHPExcel_IOFactory::createWriter($objExcel, 'Excel2007');

        $objActSheet = $objExcel->getActiveSheet();
        $key = ord("A");
        $letter =explode(',',"A,B,C,D");
        $arrHeader =  array('ID','活动','分值','学号');;
        //填充表头信息
        $lenth =  count($arrHeader);
        for($i = 0;$i < $lenth;$i++) {
            $objActSheet->setCellValue("$letter[$i]1","$arrHeader[$i]");
        };
        //填充表格信息
        foreach($data as $k=>$v){
            $k +=2;
            $objActSheet->setCellValue('A'.$k,$v['id']);
            $objActSheet->setCellValue('B'.$k, $v['aid']);
            // 表格内容
            $objActSheet->setCellValue('C'.$k, $v['value']);
            $objActSheet->setCellValue('D'.$k, $v['sid']);
            // 表格高度
            $objActSheet->getRowDimension($k)->setRowHeight(20);
        }

        $width = array(10,100,10,20);
        //设置表格的宽度
        $objActSheet->getColumnDimension('A')->setWidth($width[0]);
        $objActSheet->getColumnDimension('B')->setWidth($width[1]);
        $objActSheet->getColumnDimension('C')->setWidth($width[2]);
        $objActSheet->getColumnDimension('D')->setWidth($width[3]);


        $outfile = "活动名单".date('y-m-d').".xls";
        ob_end_clean();
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header('Content-Disposition:inline;filename="'.$outfile.'"');
        header("Content-Transfer-Encoding: binary");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Pragma: no-cache");
        $objWriter->save('php://output');

	}
	
}