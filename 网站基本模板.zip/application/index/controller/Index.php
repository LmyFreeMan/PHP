<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Session;
class Index extends Controller
{
	public function _initialize()
    {
		#网站基本信息加载
		$settinginfo=Db::name("settinginfo")->find();
		$this->assign("settinginfo",$settinginfo);
		#导航条加载
        $navinfo=Db::name("sys_navinfo")->where("display",1)->select();
		$this->assign("navinfo",$navinfo);
		#轮播图加载
		$slider=Db::name("activeinfo")->where("product",1)->select();
		$this->assign("slider",$slider);
		
    }
    public function index()
    {
		
		$actinfo=Db::name("activeinfo")->order("time desc")->select();
		$this->assign("actinfo",$actinfo);
        return $this->fetch('index');
    }
	public function login()
	{
		return $this->fetch('login');
	}
	public function cheakuser()
	{
		$username=Request::instance()->param('username');
		$password=Request::instance()->param('password');
		try{ 
				$client = new \SoapClient(null, array(
				   'location' => "http://222.30.226.3/soap/server1.php",
				   'uri'      => "http://222.30.226.3/soap/server1.php",
				   'trace'    => 1,
				   'exceptions'=>1  ));

					$result = $client->__soapCall("getinfom",array('login'=>array("xh"=>$username,"pw"=>$password,'token'=>'aa')));
					
			 }catch (SoapFault $e){
			 $result = array(
				   'error' => $e->faultstring
				 );
		}
		if(isset($result['error']))
			$this->error($result['error']);
		$stuinfo=Db::name('studentinfo')->where('id',$username)->find();
		
		if(!isset($stuinfo))
		{
			$data['id']=$username;
			$data['password']=$password;
			$data['cname']=$result[0]['XZB'];
			$data['XM']=$result[0]['XM'];
			Db::name('studentinfo')->insert($data);
		}
			Session::set('userinfo',$result);
			$this->success('登录成功！');
	}
	public function quit()
	{
		Session::delete('userinfo');
		$this->success('退出成功');
	}
	public function newslist()
	{
		$actinfo=Db::name("activeinfo")->order("time desc")->select();
		$this->assign("actinfo",$actinfo);
        return $this->fetch('newslist');
	}
	public function news($id)
	{
		$actinfo=Db::name("activeinfo")->where("id",$id)->find();
		$this->assign("actinfo",$actinfo);
        return $this->fetch('news');
	}
	public function addstuact($id)
	{
		$userinfo=Session::get('userinfo');
		$actinfo=Db::name('activeinfo')->where('id',$id)->find();
		
		$time1=date("Y-m-d H:i:s");                              //获取当前时间
		$time2=$actinfo['time'];                              //给变量$time2设置一个时间
		if(isset($userinfo))
		{
			
			if(strtotime($time1)>strtotime($time2)){
			  $this->error("已过报名时间无法报名！");
			 }
			 else if(Db::name("activelog")->where(["aid"=>$id,"sid"=>$userinfo[0]['XH']])->count()<>0){
			  $this->error("你已报名无法重复报名！");
			 }
			 else if(Db::name("activelog")->where(["aid"=>$id,"sid"=>$userinfo[0]['XH']])->count()==$actinfo['total'])
			 {
				 $this->error("报名人数已达上限！");
			 }
			else {
				Db::name('activelog')->insert(['aid'=>$id,'value'=>$actinfo['value'],'sid'=>$userinfo[0]['XH']]);
				$this->success('报名成功!');
			}
		}
		else
			$this->error('未登录,请先登录！',url('/index'));
	}
	public function personal()
	{
		$userinfo=session::get("userinfo");
		$act = model('ActivelogModel');
		$data=$act->where("sid",$userinfo[0]['XH'])->select();
		$stuinfo=Db::name("studentinfo")->where("id",$userinfo[0]['XH'])->find();
		$this->assign("stuinfo",$stuinfo);
		$this->assign("actlog",$data->toarray());
		
		return $this->fetch();
	}
}
