<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

return [
    '__pattern__' => [
        'name' => '\w+',
    ],
	'index'=>'index/index/index',
	'cheak'=>'index/index/cheakuser',
    'newslist'=>'index/index/newslist',
    'news/:id'=>'index/index/news',
	'Upload'=>'index/Upload/index',
	'addstuact/:id'=>'index/index/addstuact',
	'quit'=>'index/index/quit',
	'personal'=>'index/index/personal'
	
];
